SOPHIA STACK — your self-hosted, AI-built website

WHAT THIS IS
  A website you own. After a one-time setup, you hand any AI (ChatGPT, Claude, Grok)
  a key + your URL and it builds the site live — no SSH, no redeploys. Your edits
  persist in ./.sophia-data (keep that folder across updates). Zero npm install.

DEPLOY ON HOSTINGER (Setup Node.js App)
  1. Upload this folder (or its .zip) into your domain's directory in hPanel File
     Manager, and Extract it there.
  2. hPanel -> Advanced -> Setup Node.js App:
       - Application root: the folder you extracted (the one containing app.js)
       - Application startup file: app.js
       - Node version: 18 or higher
     Create, then Start/Restart.
  3. Open https://yourdomain/ in a browser.
  (Same idea on Railway/Render/a VPS: start file = app.js, Node >= 18.)

FIRST RUN
  1. On your site, click "Get started".
  2. Create your admin username + password (stored automatically).
     -> SAVE the five-word recovery string shown ONCE. It is your only way back in
        if you lose the password or someone else gets it.
  3. You land in your Dashboard. On the "Connect" tab, "Mint a new key" (mykey-...).

PUT YOUR AI TO WORK (no CLI — just a chat)
  In ChatGPT / Claude / Grok, paste:
    "Read https://yourdomain/skill.md, then build my website using key mykey-XXXX."
  The AI reads the skill, connects with the key, and builds — pages, design, data,
  photos/video, even sandboxed backend logic. Watch it live at https://yourdomain/.

YOUR DASHBOARD (https://yourdomain/dashboard)
  Pages - Data - Media (upload photos/files/video) - Keys (revoke anytime) -
  Settings (site description + optional "Sign in with Google" with your own OAuth app).

SAFE BY DEFAULT
  Every edit is validated before it lands; bad edits are rejected. Version history +
  one-call rollback. The footer (Admin + "Powered by Sophia Stack") and the core
  cannot be edited away. SECURITY.txt explains exactly what the AI can and cannot do.
